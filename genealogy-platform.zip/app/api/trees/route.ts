import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"

import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function GET(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const trees = await db.tree.findMany({
      where: {
        userId: session.user.id,
      },
      include: {
        _count: {
          select: {
            persons: true,
          },
        },
      },
    })

    return NextResponse.json(trees, { status: 200 })
  } catch (error) {
    console.error("Get trees error:", error)
    return NextResponse.json({ error: "Failed to get trees" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { name, description } = await req.json()

    const tree = await db.tree.create({
      data: {
        name,
        description,
        userId: session.user.id,
      },
    })

    return NextResponse.json(tree, { status: 201 })
  } catch (error) {
    console.error("Create tree error:", error)
    return NextResponse.json({ error: "Failed to create tree" }, { status: 500 })
  }
}

import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"

import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function GET(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const personId = searchParams.get("personId")

    if (!personId) {
      return NextResponse.json({ error: "Person ID is required" }, { status: 400 })
    }

    const dnaMatches = await db.dnaMatch.findMany({
      where: {
        personId,
        person: {
          userId: session.user.id,
        },
      },
    })

    return NextResponse.json(dnaMatches, { status: 200 })
  } catch (error) {
    console.error("Get DNA matches error:", error)
    return NextResponse.json({ error: "Failed to get DNA matches" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { personId, matchName, sharedCentimorgans, segments, largestSegment, relationshipType, source, notes } =
      await req.json()

    // Verify the person belongs to the user
    const person = await db.person.findUnique({
      where: {
        id: personId,
        userId: session.user.id,
      },
    })

    if (!person) {
      return NextResponse.json({ error: "Person not found or unauthorized" }, { status: 404 })
    }

    const dnaMatch = await db.dnaMatch.create({
      data: {
        personId,
        matchName,
        sharedCentimorgans,
        segments,
        largestSegment,
        relationshipType,
        source,
        notes,
      },
    })

    return NextResponse.json(dnaMatch, { status: 201 })
  } catch (error) {
    console.error("Create DNA match error:", error)
    return NextResponse.json({ error: "Failed to create DNA match" }, { status: 500 })
  }
}

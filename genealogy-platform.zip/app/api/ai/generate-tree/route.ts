import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"

import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"
import { generateTreeFromData } from "@/lib/openai"

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { dnaMatches, treeName } = await req.json()

    // Generate tree structure using OpenAI
    const treeStructure = await generateTreeFromData(dnaMatches)

    // Create a new tree
    const tree = await db.tree.create({
      data: {
        name: treeName || "AI Generated Tree",
        userId: session.user.id,
      },
    })

    // Parse the tree structure and create persons and relationships
    // This is a simplified version - in reality, you'd need to parse the AI response
    // and create the appropriate records

    return NextResponse.json({ tree, treeStructure }, { status: 201 })
  } catch (error) {
    console.error("AI tree generation error:", error)
    return NextResponse.json({ error: "Failed to generate tree" }, { status: 500 })
  }
}

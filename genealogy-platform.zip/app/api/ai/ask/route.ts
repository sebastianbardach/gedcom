import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"

import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"
import { askAboutPerson } from "@/lib/openai"

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { personId, question } = await req.json()

    // Get person data
    const person = await db.person.findUnique({
      where: {
        id: personId,
      },
      include: {
        relationships: {
          include: {
            relatedTo: true,
          },
        },
        dnaMatches: true,
        knowledgeItems: true,
      },
    })

    if (!person) {
      return NextResponse.json({ error: "Person not found" }, { status: 404 })
    }

    // Generate answer using OpenAI
    const answer = await askAboutPerson(person, question)

    // Save the question and answer
    const knowledgeItem = await db.knowledgeItem.create({
      data: {
        personId,
        question,
        answer,
      },
    })

    return NextResponse.json({ answer, knowledgeItem }, { status: 200 })
  } catch (error) {
    console.error("AI assistant error:", error)
    return NextResponse.json({ error: "Failed to answer question" }, { status: 500 })
  }
}

import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"

import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { personId, relatedToId, type } = await req.json()

    // Verify both persons belong to the user
    const persons = await db.person.findMany({
      where: {
        id: {
          in: [personId, relatedToId],
        },
        userId: session.user.id,
      },
    })

    if (persons.length !== 2) {
      return NextResponse.json({ error: "Persons not found or unauthorized" }, { status: 404 })
    }

    const relationship = await db.relationship.create({
      data: {
        personId,
        relatedToId,
        type,
      },
    })

    // Create the inverse relationship if needed
    let inverseType = ""
    if (type === "parent") {
      inverseType = "child"
    } else if (type === "child") {
      inverseType = "parent"
    } else if (type === "spouse") {
      inverseType = "spouse"
    } else if (type === "sibling") {
      inverseType = "sibling"
    }

    if (inverseType && type !== "spouse" && type !== "sibling") {
      await db.relationship.create({
        data: {
          personId: relatedToId,
          relatedToId: personId,
          type: inverseType,
        },
      })
    }

    return NextResponse.json(relationship, { status: 201 })
  } catch (error) {
    console.error("Create relationship error:", error)
    return NextResponse.json({ error: "Failed to create relationship" }, { status: 500 })
  }
}

export async function DELETE(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Relationship ID is required" }, { status: 400 })
    }

    // Verify the relationship belongs to the user's persons
    const relationship = await db.relationship.findUnique({
      where: {
        id,
      },
      include: {
        person: true,
      },
    })

    if (!relationship || relationship.person.userId !== session.user.id) {
      return NextResponse.json({ error: "Relationship not found or unauthorized" }, { status: 404 })
    }

    await db.relationship.delete({
      where: {
        id,
      },
    })

    return NextResponse.json({ success: true }, { status: 200 })
  } catch (error) {
    console.error("Delete relationship error:", error)
    return NextResponse.json({ error: "Failed to delete relationship" }, { status: 500 })
  }
}

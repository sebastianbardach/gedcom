import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"

import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function GET(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const treeId = searchParams.get("treeId")

    const where = {
      userId: session.user.id,
      ...(treeId ? { treeId } : {}),
    }

    const persons = await db.person.findMany({
      where,
      include: {
        relationships: {
          include: {
            relatedTo: true,
          },
        },
      },
    })

    return NextResponse.json(persons, { status: 200 })
  } catch (error) {
    console.error("Get persons error:", error)
    return NextResponse.json({ error: "Failed to get persons" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { firstName, lastName, birthDate, deathDate, gender, notes, treeId } = await req.json()

    const person = await db.person.create({
      data: {
        firstName,
        lastName,
        birthDate: birthDate ? new Date(birthDate) : undefined,
        deathDate: deathDate ? new Date(deathDate) : undefined,
        gender,
        notes,
        treeId,
        userId: session.user.id,
      },
    })

    return NextResponse.json(person, { status: 201 })
  } catch (error) {
    console.error("Create person error:", error)
    return NextResponse.json({ error: "Failed to create person" }, { status: 500 })
  }
}

import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { Plus } from "lucide-react"

import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"
import { Button } from "@/components/ui/button"
import DashboardHeader from "@/components/dashboard-header"
import TreeCard from "@/components/tree-card"
import EmptyState from "@/components/empty-state"

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/login")
  }

  const trees = await db.tree.findMany({
    where: {
      userId: session.user.id,
    },
    include: {
      _count: {
        select: {
          persons: true,
        },
      },
    },
    orderBy: {
      updatedAt: "desc",
    },
  })

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={session.user} />
      <main className="flex-1 container py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Your Family Trees</h1>
          <Button asChild>
            <a href="/dashboard/trees/new">
              <Plus className="h-4 w-4 mr-2" />
              New Tree
            </a>
          </Button>
        </div>

        {trees.length === 0 ? (
          <EmptyState
            title="No trees found"
            description="Get started by creating your first family tree."
            action={
              <Button asChild>
                <a href="/dashboard/trees/new">
                  <Plus className="h-4 w-4 mr-2" />
                  New Tree
                </a>
              </Button>
            }
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trees.map((tree) => (
              <TreeCard key={tree.id} tree={tree} />
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

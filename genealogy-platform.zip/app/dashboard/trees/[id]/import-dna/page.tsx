"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Dna, ArrowLeft, Upload, FileText } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ImportDnaPageProps {
  params: {
    id: string
  }
}

export default function ImportDnaPage({ params }: ImportDnaPageProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("23andme")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [file, setFile] = useState<File | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0])
    }
  }

  const handleImport = async () => {
    setIsLoading(true)
    setError(null)

    try {
      // Simulate file upload and processing
      setTimeout(() => {
        router.push(`/dashboard/trees/${params.id}/ai-processing`)
      }, 2000)

      // In a real implementation, you would upload the file and process it
      // const formData = new FormData();
      // if (file) {
      //   formData.append('file', file);
      // }
      // formData.append('source', activeTab);
      // formData.append('treeId', params.id);
      //
      // const response = await fetch('/api/dna-matches/import', {
      //   method: 'POST',
      //   body: formData,
      // });
      //
      // const data = await response.json();
      //
      // if (!response.ok) {
      //   throw new Error(data.error || 'Failed to import DNA matches');
      // }
      //
      // router.push(`/dashboard/trees/${params.id}/ai-processing`);
    } catch (error) {
      if (error instanceof Error) {
        setError(error.message)
      } else {
        setError("Something went wrong. Please try again.")
      }
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-gray-50">
      <header className="border-b bg-white">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <Button variant="ghost" size="icon" onClick={() => router.push(`/dashboard/trees/${params.id}`)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2 font-bold text-xl ml-2">
            <Dna className="h-6 w-6" />
            <span>Import DNA Matches</span>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>Import DNA Matches</CardTitle>
            <CardDescription>
              Import your DNA matches from popular testing services to enhance your family tree.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <div className="rounded-md bg-red-50 p-4 mb-4">
                <div className="flex">
                  <div className="text-sm text-red-700">{error}</div>
                </div>
              </div>
            )}
            <Tabs defaultValue="23andme" className="w-full" onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3 mb-4">
                <TabsTrigger value="23andme">23andMe</TabsTrigger>
                <TabsTrigger value="ancestry">AncestryDNA</TabsTrigger>
                <TabsTrigger value="myheritage">MyHeritage</TabsTrigger>
              </TabsList>
              <TabsContent value="23andme" className="space-y-4">
                <div className="rounded-lg border border-dashed p-6 text-center">
                  <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
                    <div className="mb-4 rounded-full bg-blue-50 p-3">
                      <Upload className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="mb-1 text-lg font-semibold">Upload 23andMe Data</h3>
                    <p className="mb-4 text-sm text-gray-500">
                      Export your DNA matches from 23andMe and upload the CSV file here.
                    </p>
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <div className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500">
                        Select File
                      </div>
                      <input
                        id="file-upload"
                        name="file-upload"
                        type="file"
                        accept=".csv,.txt"
                        className="sr-only"
                        onChange={handleFileChange}
                      />
                    </label>
                    {file && (
                      <div className="mt-4 flex items-center gap-2 text-sm text-gray-500">
                        <FileText className="h-4 w-4" />
                        <span>{file.name}</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="rounded-lg bg-blue-50 p-4 text-sm text-blue-800">
                  <h4 className="font-medium">How to export your 23andMe data:</h4>
                  <ol className="list-decimal pl-5 mt-2 space-y-1">
                    <li>Log in to your 23andMe account</li>
                    <li>Go to "DNA Relatives" under "Family & Friends"</li>
                    <li>Click on "Download" at the top of the page</li>
                    <li>Select "All DNA Relatives" and download the CSV file</li>
                  </ol>
                </div>
              </TabsContent>
              <TabsContent value="ancestry" className="space-y-4">
                <div className="rounded-lg border border-dashed p-6 text-center">
                  <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
                    <div className="mb-4 rounded-full bg-blue-50 p-3">
                      <Upload className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="mb-1 text-lg font-semibold">Upload AncestryDNA Data</h3>
                    <p className="mb-4 text-sm text-gray-500">
                      Export your DNA matches from AncestryDNA and upload the CSV file here.
                    </p>
                    <label htmlFor="file-upload-ancestry" className="cursor-pointer">
                      <div className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500">
                        Select File
                      </div>
                      <input
                        id="file-upload-ancestry"
                        name="file-upload-ancestry"
                        type="file"
                        accept=".csv,.txt"
                        className="sr-only"
                        onChange={handleFileChange}
                      />
                    </label>
                    {file && (
                      <div className="mt-4 flex items-center gap-2 text-sm text-gray-500">
                        <FileText className="h-4 w-4" />
                        <span>{file.name}</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="rounded-lg bg-blue-50 p-4 text-sm text-blue-800">
                  <h4 className="font-medium">How to export your AncestryDNA data:</h4>
                  <ol className="list-decimal pl-5 mt-2 space-y-1">
                    <li>Log in to your Ancestry account</li>
                    <li>Go to "DNA" and then "DNA Matches"</li>
                    <li>Click on the "Download" button</li>
                    <li>Select "All Matches" and download the CSV file</li>
                  </ol>
                </div>
              </TabsContent>
              <TabsContent value="myheritage" className="space-y-4">
                <div className="rounded-lg border border-dashed p-6 text-center">
                  <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
                    <div className="mb-4 rounded-full bg-blue-50 p-3">
                      <Upload className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="mb-1 text-lg font-semibold">Upload MyHeritage Data</h3>
                    <p className="mb-4 text-sm text-gray-500">
                      Export your DNA matches from MyHeritage and upload the CSV file here.
                    </p>
                    <label htmlFor="file-upload-myheritage" className="cursor-pointer">
                      <div className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500">
                        Select File
                      </div>
                      <input
                        id="file-upload-myheritage"
                        name="file-upload-myheritage"
                        type="file"
                        accept=".csv,.txt"
                        className="sr-only"
                        onChange={handleFileChange}
                      />
                    </label>
                    {file && (
                      <div className="mt-4 flex items-center gap-2 text-sm text-gray-500">
                        <FileText className="h-4 w-4" />
                        <span>{file.name}</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="rounded-lg bg-blue-50 p-4 text-sm text-blue-800">
                  <h4 className="font-medium">How to export your MyHeritage data:</h4>
                  <ol className="list-decimal pl-5 mt-2 space-y-1">
                    <li>Log in to your MyHeritage account</li>
                    <li>Go to "DNA" and then "DNA Matches"</li>
                    <li>Click on the "Export" button</li>
                    <li>Select "All Matches" and download the CSV file</li>
                  </ol>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => router.push(`/dashboard/trees/${params.id}`)}>
              Skip for Now
            </Button>
            <Button onClick={handleImport} disabled={isLoading || !file}>
              {isLoading ? "Importing..." : "Import Matches"}
            </Button>
          </CardFooter>
        </Card>
      </main>
    </div>
  )
}

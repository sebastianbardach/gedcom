import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { Plus, Edit, Download, Share2 } from "lucide-react"

import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"
import { Button } from "@/components/ui/button"
import DashboardHeader from "@/components/dashboard-header"
import FamilyTreeViewer from "@/components/family-tree-viewer"
import AiAssistant from "@/components/ai-assistant"

interface TreePageProps {
  params: {
    id: string
  }
}

export default async function TreePage({ params }: TreePageProps) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/login")
  }

  const tree = await db.tree.findUnique({
    where: {
      id: params.id,
      userId: session.user.id,
    },
    include: {
      persons: {
        include: {
          relationships: {
            include: {
              relatedTo: true,
            },
          },
        },
      },
    },
  })

  if (!tree) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={session.user} />
      <main className="flex-1 container py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">{tree.name}</h1>
            <p className="text-sm text-gray-500">{tree.persons.length} people in this tree</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" asChild>
              <a href={`/dashboard/trees/${tree.id}/edit`}>
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </a>
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button variant="outline" size="sm">
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
            <Button size="sm" asChild>
              <a href={`/dashboard/trees/${tree.id}/persons/new`}>
                <Plus className="h-4 w-4 mr-2" />
                Add Person
              </a>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 border rounded-lg p-4 bg-white min-h-[600px]">
            <FamilyTreeViewer tree={tree} />
          </div>
          <div className="border rounded-lg p-4 bg-white">
            <AiAssistant treeId={tree.id} />
          </div>
        </div>
      </main>
    </div>
  )
}

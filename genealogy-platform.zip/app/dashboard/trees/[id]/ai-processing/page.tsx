"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Dna, Brain, Check, ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface AiProcessingPageProps {
  params: {
    id: string
  }
}

export default function AiProcessingPage({ params }: AiProcessingPageProps) {
  const router = useRouter()
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(0)
  const [isComplete, setIsComplete] = useState(false)

  const steps = [
    "Analyzing DNA matches",
    "Identifying relationships",
    "Building family connections",
    "Generating family tree",
    "Finalizing tree structure",
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prevProgress) => {
        if (prevProgress >= 100) {
          clearInterval(interval)
          setIsComplete(true)
          return 100
        }

        const newProgress = prevProgress + 5

        // Update current step based on progress
        if (newProgress < 20) {
          setCurrentStep(0)
        } else if (newProgress < 40) {
          setCurrentStep(1)
        } else if (newProgress < 60) {
          setCurrentStep(2)
        } else if (newProgress < 80) {
          setCurrentStep(3)
        } else {
          setCurrentStep(4)
        }

        return newProgress
      })
    }, 500)

    return () => clearInterval(interval)
  }, [])

  const handleViewTree = () => {
    router.push(`/dashboard/trees/${params.id}`)
  }

  return (
    <div className="flex min-h-screen flex-col bg-gray-50">
      <header className="border-b bg-white">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <div className="flex items-center gap-2 font-bold text-xl">
            <Dna className="h-6 w-6" />
            <span>AI Tree Generation</span>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>Building Your Family Tree</CardTitle>
            <CardDescription>
              Our AI is analyzing your DNA matches and building your family tree. This may take a few minutes.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} />
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-blue-100 p-3">
                  <Brain className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium">AI Processing</h3>
                  <p className="text-sm text-gray-500">
                    {isComplete ? "Processing complete!" : `Currently: ${steps[currentStep]}`}
                  </p>
                </div>
              </div>

              <ul className="space-y-2">
                {steps.map((step, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <div
                      className={`flex h-6 w-6 items-center justify-center rounded-full ${
                        index < currentStep || isComplete
                          ? "bg-green-100 text-green-600"
                          : index === currentStep && !isComplete
                            ? "bg-blue-100 text-blue-600"
                            : "bg-gray-100 text-gray-400"
                      }`}
                    >
                      {index < currentStep || isComplete ? (
                        <Check className="h-4 w-4" />
                      ) : (
                        <span className="text-xs">{index + 1}</span>
                      )}
                    </div>
                    <span
                      className={`text-sm ${
                        index < currentStep || isComplete
                          ? "text-gray-900"
                          : index === currentStep && !isComplete
                            ? "text-gray-900 font-medium"
                            : "text-gray-500"
                      }`}
                    >
                      {step}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full" onClick={handleViewTree} disabled={!isComplete}>
              {isComplete ? (
                <>
                  View Your Family Tree
                  <ArrowRight className="ml-2 h-4 w-4" />
                </>
              ) : (
                "Processing..."
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
    </div>
  )
}

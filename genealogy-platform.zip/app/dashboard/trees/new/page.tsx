"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Dna, ArrowLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function NewTreePage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("manual")
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleCreateTree = async () => {
    if (!name.trim()) {
      setError("Tree name is required")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/trees", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          description,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create tree")
      }

      router.push(`/dashboard/trees/${data.id}`)
    } catch (error) {
      if (error instanceof Error) {
        setError(error.message)
      } else {
        setError("Something went wrong. Please try again.")
      }
      setIsLoading(false)
    }
  }

  const handleCreateAiTree = async () => {
    if (!name.trim()) {
      setError("Tree name is required")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      // First create an empty tree
      const response = await fetch("/api/trees", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          description,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create tree")
      }

      // Redirect to the import DNA matches page
      router.push(`/dashboard/trees/${data.id}/import-dna`)
    } catch (error) {
      if (error instanceof Error) {
        setError(error.message)
      } else {
        setError("Something went wrong. Please try again.")
      }
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-gray-50">
      <header className="border-b bg-white">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2 font-bold text-xl ml-2">
            <Dna className="h-6 w-6" />
            <span>Create New Family Tree</span>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>Create a New Family Tree</CardTitle>
            <CardDescription>
              Start building your family history by creating a new tree. You can start from scratch or use our AI to
              help you build your tree.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <div className="rounded-md bg-red-50 p-4 mb-4">
                <div className="flex">
                  <div className="text-sm text-red-700">{error}</div>
                </div>
              </div>
            )}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Tree Name</Label>
                <Input id="name" placeholder="My Family Tree" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea
                  id="description"
                  placeholder="Add a description for your family tree"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Tabs defaultValue="manual" className="w-full" onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="manual">Start from Scratch</TabsTrigger>
                <TabsTrigger value="ai">Build with AI</TabsTrigger>
              </TabsList>
              <TabsContent value="manual" className="space-y-4">
                <p className="text-sm text-gray-500">
                  Create an empty tree and add family members manually. You'll be able to add people, relationships, and
                  details at your own pace.
                </p>
                <Button className="w-full" onClick={handleCreateTree} disabled={isLoading}>
                  {isLoading ? "Creating..." : "Create Tree"}
                </Button>
              </TabsContent>
              <TabsContent value="ai" className="space-y-4">
                <p className="text-sm text-gray-500">
                  Import your DNA matches and let our AI help you build your family tree. We'll analyze your data and
                  suggest relationships.
                </p>
                <Button className="w-full" onClick={handleCreateAiTree} disabled={isLoading}>
                  {isLoading ? "Creating..." : "Continue to DNA Import"}
                </Button>
              </TabsContent>
            </Tabs>
          </CardFooter>
        </Card>
      </main>
    </div>
  )
}

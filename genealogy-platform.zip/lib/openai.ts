import { OpenAI } from "openai"

export const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function generateTreeFromData(data: any) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a genealogy expert that helps analyze DNA matches and family relationships.",
        },
        {
          role: "user",
          content: `Analyze the following DNA match data and suggest a family tree structure: ${JSON.stringify(data)}`,
        },
      ],
      temperature: 0.7,
    })

    return response.choices[0].message.content
  } catch (error) {
    console.error("OpenAI API error:", error)
    throw new Error("Failed to generate tree from data")
  }
}

export async function askAboutPerson(personData: any, question: string) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are a genealogy expert that helps answer questions about family members based on available data.",
        },
        {
          role: "user",
          content: `Based on this person's data: ${JSON.stringify(personData)}, answer the following question: ${question}`,
        },
      ],
      temperature: 0.7,
    })

    return response.choices[0].message.content
  } catch (error) {
    console.error("OpenAI API error:", error)
    throw new Error("Failed to answer question about person")
  }
}

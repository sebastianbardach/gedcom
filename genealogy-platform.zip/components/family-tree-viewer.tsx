"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { ZoomIn, ZoomOut, Move } from "lucide-react"

import { Button } from "@/components/ui/button"

interface Person {
  id: string
  firstName: string
  lastName: string
  birthDate: Date | null
  deathDate: Date | null
  gender: string | null
  relationships: Relationship[]
}

interface Relationship {
  id: string
  type: string
  personId: string
  relatedToId: string
  relatedTo: Person
}

interface Tree {
  id: string
  name: string
  persons: Person[]
}

interface FamilyTreeViewerProps {
  tree: Tree
}

export default function FamilyTreeViewer({ tree }: FamilyTreeViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [zoom, setZoom] = useState(1)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [treeData, setTreeData] = useState<any>(null)

  useEffect(() => {
    if (tree.persons.length > 0) {
      // Process tree data to create a hierarchical structure
      const processedData = processTreeData(tree.persons)
      setTreeData(processedData)
    }
  }, [tree])

  const processTreeData = (persons: Person[]) => {
    // Find root persons (those without parents)
    const rootPersons = persons.filter((person) => {
      return !person.relationships.some((rel) => rel.type === "child")
    })

    if (rootPersons.length === 0 && persons.length > 0) {
      // If no root persons found but there are persons, use the first person as root
      return buildPersonNode(persons[0], persons)
    }

    return rootPersons.map((person) => buildPersonNode(person, persons))
  }

  const buildPersonNode = (person: Person, allPersons: Person[]) => {
    const children = person.relationships
      .filter((rel) => rel.type === "parent")
      .map((rel) => {
        const child = allPersons.find((p) => p.id === rel.relatedToId)
        return child ? buildPersonNode(child, allPersons) : null
      })
      .filter(Boolean)

    const spouses = person.relationships
      .filter((rel) => rel.type === "spouse")
      .map((rel) => {
        const spouse = allPersons.find((p) => p.id === rel.relatedToId)
        return spouse
          ? {
              id: spouse.id,
              name: `${spouse.firstName} ${spouse.lastName}`,
              birthDate: spouse.birthDate,
              deathDate: spouse.deathDate,
              gender: spouse.gender,
            }
          : null
      })
      .filter(Boolean)

    return {
      id: person.id,
      name: `${person.firstName} ${person.lastName}`,
      birthDate: person.birthDate,
      deathDate: person.deathDate,
      gender: person.gender,
      children,
      spouses,
    }
  }

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.1, 2))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.1, 0.5))
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX, y: e.clientY })
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: position.x + (e.clientX - dragStart.x),
        y: position.y + (e.clientY - dragStart.y),
      })
      setDragStart({ x: e.clientX, y: e.clientY })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const renderPersonNode = (node: any, level = 0, index = 0) => {
    if (!node) return null

    const birthYear = node.birthDate ? new Date(node.birthDate).getFullYear() : ""
    const deathYear = node.deathDate ? new Date(node.deathDate).getFullYear() : ""
    const yearsText = birthYear || deathYear ? `(${birthYear}${deathYear ? ` - ${deathYear}` : ""})` : ""

    return (
      <div key={node.id} className="flex flex-col items-center" style={{ marginLeft: index * 20 }}>
        <div
          className={`p-3 rounded-lg border ${node.gender === "male" ? "bg-blue-50" : node.gender === "female" ? "bg-pink-50" : "bg-gray-50"} min-w-[150px] text-center mb-2`}
        >
          <div className="font-medium">{node.name}</div>
          {yearsText && <div className="text-xs text-gray-500">{yearsText}</div>}
        </div>

        {node.spouses && node.spouses.length > 0 && (
          <div className="flex flex-col gap-2 mb-2">
            {node.spouses.map((spouse: any) => (
              <div key={spouse.id} className="flex items-center gap-2">
                <div className="w-10 h-0.5 bg-gray-300"></div>
                <div
                  className={`p-3 rounded-lg border ${spouse.gender === "male" ? "bg-blue-50" : spouse.gender === "female" ? "bg-pink-50" : "bg-gray-50"} min-w-[150px] text-center`}
                >
                  <div className="font-medium">{spouse.name}</div>
                  {spouse.birthDate && (
                    <div className="text-xs text-gray-500">
                      {new Date(spouse.birthDate).getFullYear()}
                      {spouse.deathDate && ` - ${new Date(spouse.deathDate).getFullYear()}`}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {node.children && node.children.length > 0 && (
          <div className="mt-4">
            <div className="w-0.5 h-4 bg-gray-300 mx-auto"></div>
            <div className="flex flex-wrap justify-center gap-4">
              {node.children.map((child: any, i: number) => renderPersonNode(child, level + 1, i))}
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <div className="text-lg font-medium">Family Tree</div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={handleZoomOut}>
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="text-sm">{Math.round(zoom * 100)}%</span>
          <Button variant="outline" size="icon" onClick={handleZoomIn}>
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon">
            <Move className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div
        className="flex-1 overflow-auto border rounded-lg bg-gray-50"
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <div
          className="p-8 inline-block min-w-full min-h-full"
          style={{
            transform: `scale(${zoom}) translate(${position.x}px, ${position.y}px)`,
            transformOrigin: "0 0",
            cursor: isDragging ? "grabbing" : "grab",
          }}
        >
          {treeData ? (
            <div className="flex flex-col items-center">
              {Array.isArray(treeData)
                ? treeData.map((node, i) => renderPersonNode(node, 0, i))
                : renderPersonNode(treeData)}
            </div>
          ) : (
            <div className="flex items-center justify-center h-full">
              <p className="text-gray-500">No family tree data available. Add people to get started.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

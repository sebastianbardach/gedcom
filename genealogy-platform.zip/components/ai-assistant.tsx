"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Send, Bot, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface AiAssistantProps {
  treeId: string
}

interface Message {
  role: "user" | "assistant"
  content: string
}

export default function AiAssistant({ treeId }: AiAssistantProps) {
  const [activeTab, setActiveTab] = useState("chat")
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm your genealogy assistant. How can I help you with your family tree today?",
    },
  ])
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage = input.trim()
    setInput("")
    setMessages((prev) => [...prev, { role: "user", content: userMessage }])
    setIsLoading(true)

    try {
      // Simulate AI response for now
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: `I'm analyzing your question about "${userMessage}". As this is a demo, I'm providing a simulated response. In the full version, I would use AI to analyze your family tree data and provide accurate insights.`,
          },
        ])
        setIsLoading(false)
      }, 1500)

      // In a real implementation, you would call your AI API
      // const response = await fetch('/api/ai/ask', {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   body: JSON.stringify({
      //     treeId,
      //     question: userMessage,
      //   }),
      // });
      //
      // const data = await response.json();
      // setMessages(prev => [...prev, { role: 'assistant', content: data.answer }]);
    } catch (error) {
      console.error("Error sending message:", error)
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Sorry, I encountered an error. Please try again." },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="h-full flex flex-col">
      <Tabs defaultValue="chat" className="w-full h-full flex flex-col">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="chat" onClick={() => setActiveTab("chat")}>
            Chat
          </TabsTrigger>
          <TabsTrigger value="knowledge" onClick={() => setActiveTab("knowledge")}>
            Knowledge Base
          </TabsTrigger>
        </TabsList>
        <TabsContent value="chat" className="flex-1 flex flex-col">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <div key={index} className={`flex ${message.role === "assistant" ? "justify-start" : "justify-end"}`}>
                <div
                  className={`flex max-w-[80%] rounded-lg p-3 ${
                    message.role === "assistant" ? "bg-gray-100 text-gray-900" : "bg-blue-600 text-white"
                  }`}
                >
                  <div className="mr-2 mt-0.5">
                    {message.role === "assistant" ? <Bot className="h-5 w-5" /> : <User className="h-5 w-5" />}
                  </div>
                  <div className="text-sm">{message.content}</div>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="flex max-w-[80%] rounded-lg p-3 bg-gray-100 text-gray-900">
                  <div className="mr-2 mt-0.5">
                    <Bot className="h-5 w-5" />
                  </div>
                  <div className="text-sm">Thinking...</div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          <div className="p-4 border-t">
            <div className="flex gap-2">
              <Textarea
                placeholder="Ask about your family tree..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                className="min-h-[60px]"
              />
              <Button onClick={handleSendMessage} disabled={isLoading} className="self-end">
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Ask questions about your family tree, relationships, or specific people.
            </p>
          </div>
        </TabsContent>
        <TabsContent value="knowledge" className="flex-1 overflow-y-auto">
          <div className="p-4">
            <h3 className="font-medium mb-2">Knowledge Base</h3>
            <p className="text-sm text-gray-500 mb-4">
              This is where all the knowledge about your family tree is stored. As you ask questions, the AI will build
              a knowledge base about your family members.
            </p>
            <div className="border rounded-lg p-4 bg-gray-50">
              <p className="text-sm text-center text-gray-500">
                No knowledge items yet. Start a conversation to build your knowledge base.
              </p>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

import Link from "next/link"
import { Calendar, Users } from "lucide-react"

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface TreeCardProps {
  tree: {
    id: string
    name: string
    description: string | null
    createdAt: Date
    _count: {
      persons: number
    }
  }
}

export default function TreeCard({ tree }: TreeCardProps) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-blue-50 pb-4">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg font-bold">{tree.name}</CardTitle>
          <div className="flex items-center text-sm text-gray-500">
            <Users className="h-4 w-4 mr-1" />
            <span>{tree._count.persons}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="flex items-center text-sm text-gray-500 mb-2">
          <Calendar className="h-4 w-4 mr-1" />
          <span>{new Date(tree.createdAt).toLocaleDateString()}</span>
        </div>
        <p className="text-sm text-gray-600 line-clamp-2">{tree.description || "No description provided."}</p>
      </CardContent>
      <CardFooter className="flex justify-between pt-0">
        <Button variant="outline" size="sm" asChild>
          <Link href={`/dashboard/trees/${tree.id}`}>View</Link>
        </Button>
        <Button variant="outline" size="sm" asChild>
          <Link href={`/dashboard/trees/${tree.id}/edit`}>Edit</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

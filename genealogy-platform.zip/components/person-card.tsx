import Link from "next/link"
import { Calendar, User } from "lucide-react"

import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

interface PersonCardProps {
  person: {
    id: string
    firstName: string
    lastName: string
    birthDate: Date | null
    deathDate: Date | null
    gender: string | null
  }
}

export default function PersonCard({ person }: PersonCardProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  const fullName = `${person.firstName} ${person.lastName}`
  const birthYear = person.birthDate ? new Date(person.birthDate).getFullYear() : null
  const deathYear = person.deathDate ? new Date(person.deathDate).getFullYear() : null

  return (
    <Card className="overflow-hidden">
      <CardHeader
        className={`flex items-center justify-center pt-6 pb-4 ${
          person.gender === "male" ? "bg-blue-50" : person.gender === "female" ? "bg-pink-50" : "bg-gray-50"
        }`}
      >
        <Avatar className="h-20 w-20">
          <AvatarFallback className="text-lg">{getInitials(fullName)}</AvatarFallback>
        </Avatar>
      </CardHeader>
      <CardContent className="pt-4">
        <h3 className="font-medium text-center mb-2">{fullName}</h3>
        <div className="flex flex-col gap-1 text-sm text-gray-500">
          {(birthYear || deathYear) && (
            <div className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              <span>
                {birthYear ? birthYear : "?"}
                {deathYear ? ` - ${deathYear}` : ""}
              </span>
            </div>
          )}
          {person.gender && (
            <div className="flex items-center gap-1">
              <User className="h-3 w-3" />
              <span>{person.gender.charAt(0).toUpperCase() + person.gender.slice(1)}</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-center pt-0">
        <Button variant="outline" size="sm" asChild>
          <Link href={`/dashboard/persons/${person.id}`}>View Profile</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
